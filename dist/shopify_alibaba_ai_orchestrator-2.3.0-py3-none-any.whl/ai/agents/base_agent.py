from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable


@dataclass(frozen=True, slots=True)
class AgentDecision:
    agent: str
    decision: str
    confidence: float
    score: float
    reasons: tuple[str, ...]
    approval_required: bool = False
    blocked: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class PolicyAwareAgent:
    """Base déterministe et légère pour les agents métier.

    Le moteur ne dépend d'aucun LLM. Il combine des signaux normalisés, applique
    des blocages durs, puis décide entre approve/review/reject. Chaque décision
    est explicable et stable, ce qui permet de l'auditer et de la rejouer.
    """

    description = "Agent métier"
    positive_signals: tuple[str, ...] = ()
    negative_signals: tuple[str, ...] = ()
    hard_block_signals: tuple[str, ...] = ()
    approval_signals: tuple[str, ...] = ("financial_action", "irreversible_action")
    approve_threshold = 0.82
    reject_threshold = 0.35

    @staticmethod
    def _bounded(value: Any, default: float = 0.0) -> float:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return default
        if number != number or number in (float("inf"), float("-inf")):
            return default
        return max(0.0, min(1.0, number))

    @staticmethod
    def _truthy(context: dict[str, Any], names: Iterable[str]) -> tuple[str, ...]:
        return tuple(name for name in names if bool(context.get(name)))

    def score(self, context: dict[str, Any]) -> tuple[float, tuple[str, ...]]:
        explicit = context.get("score")
        if explicit is not None:
            value = self._bounded(explicit, 0.5)
            return value, ("explicit_score",)
        positives = [self._bounded(context.get(name), 0.5) for name in self.positive_signals]
        negatives = [self._bounded(context.get(name), 0.0) for name in self.negative_signals]
        base = self._bounded(context.get("confidence"), 0.75)
        components = [base, *positives]
        positive_score = sum(components) / max(1, len(components))
        penalty = (sum(negatives) / max(1, len(negatives))) * 0.65 if negatives else 0.0
        value = max(0.0, min(1.0, positive_score - penalty))
        reasons = tuple(
            [f"positive:{name}" for name in self.positive_signals if self._bounded(context.get(name), 0) >= 0.7]
            + [f"negative:{name}" for name in self.negative_signals if self._bounded(context.get(name), 0) >= 0.5]
        ) or ("baseline_confidence",)
        return value, reasons

    def decide(self, context: dict[str, Any]) -> dict[str, Any]:
        hard_blocks = self._truthy(context, self.hard_block_signals)
        approval_reasons = self._truthy(context, self.approval_signals)
        score, reasons = self.score(context)
        if hard_blocks:
            decision = AgentDecision(
                self.__class__.__name__, "reject", min(score, 0.2), score,
                tuple(f"blocked:{name}" for name in hard_blocks), blocked=True,
            )
        elif score < self.reject_threshold:
            decision = AgentDecision(self.__class__.__name__, "reject", 1.0 - score, score, reasons)
        elif approval_reasons or score < self.approve_threshold:
            decision = AgentDecision(
                self.__class__.__name__, "review", max(score, 1.0 - score), score,
                reasons + tuple(f"approval:{name}" for name in approval_reasons),
                approval_required=bool(approval_reasons),
            )
        else:
            decision = AgentDecision(self.__class__.__name__, "approve", score, score, reasons)
        payload = decision.to_dict()
        payload["description"] = self.description
        return payload
