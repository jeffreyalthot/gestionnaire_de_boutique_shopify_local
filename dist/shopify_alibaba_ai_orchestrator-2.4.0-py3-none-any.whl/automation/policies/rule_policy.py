from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class RulePolicyDecision:
    allowed: bool
    reason: str
    score: float = 1.0
    approval_required: bool = False
    detail: dict[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class RulePolicy:
    name = "generic"

    def __init__(self, *, enabled: bool = True, minimum_score: float = 0.0, approval_on_failure: bool = True) -> None:
        self.enabled = enabled
        self.minimum_score = max(0.0, min(1.0, minimum_score))
        self.approval_on_failure = approval_on_failure

    def evaluate(self, *, score: float = 1.0, violations: tuple[str, ...] = (), detail: dict[str, Any] | None = None) -> RulePolicyDecision:
        score = max(0.0, min(1.0, float(score)))
        if not self.enabled:
            return RulePolicyDecision(False, "policy_disabled", score, True, detail)
        if violations:
            return RulePolicyDecision(False, "policy_violations:" + ",".join(sorted(set(violations))), score, self.approval_on_failure, detail)
        if score < self.minimum_score:
            return RulePolicyDecision(False, "score_below_threshold", score, self.approval_on_failure, detail)
        return RulePolicyDecision(True, "allowed", score, False, detail)
