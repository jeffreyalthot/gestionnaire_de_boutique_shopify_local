from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class ActionPolicy:
    action: str
    risk: str = "read_only"
    max_amount_cad: float = 0.0
    requires_approval: bool = False
    reversible: bool = True


@dataclass(frozen=True, slots=True)
class PolicyDecision:
    allowed: bool
    simulated: bool
    approval_required: bool
    reason: str


class PolicyEngine:
    def __init__(self, *, dry_run: bool, financial_limit_cad: float = 1000.0) -> None:
        self.dry_run = dry_run
        self.financial_limit_cad = financial_limit_cad

    def evaluate(self, policy: ActionPolicy, *, amount_cad: float = 0.0, approved: bool = False) -> PolicyDecision:
        financial = policy.risk == "financial"
        irreversible = policy.risk == "irreversible"
        approval_required = policy.requires_approval or financial or irreversible
        if amount_cad < 0:
            return PolicyDecision(False, self.dry_run, approval_required, "negative_amount")
        limit = policy.max_amount_cad or self.financial_limit_cad
        if financial and amount_cad > limit:
            return PolicyDecision(False, self.dry_run, True, "financial_limit_exceeded")
        if self.dry_run:
            return PolicyDecision(True, True, approval_required, "dry_run_simulation")
        if approval_required and not approved:
            return PolicyDecision(False, False, True, "explicit_approval_required")
        return PolicyDecision(True, False, approval_required, "allowed")

    def explain(self, decision: PolicyDecision) -> dict[str, Any]:
        return {"allowed": decision.allowed, "simulated": decision.simulated, "approval_required": decision.approval_required, "reason": decision.reason}
