from automation.reconciliation.persistent_reconciler import PersistentReconciler


class InventoryReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("inventory", db)
