from automation.reconciliation.persistent_reconciler import PersistentReconciler


class CustomerReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("customer", db)
