from automation.reconciliation.persistent_reconciler import PersistentReconciler


class FinanceReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("finance", db)
