from automation.reconciliation.persistent_reconciler import PersistentReconciler


class TrackingReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("tracking", db)
