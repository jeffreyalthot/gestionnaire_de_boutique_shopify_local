from automation.reconciliation.persistent_reconciler import PersistentReconciler


class ProductMediaReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("product_media", db)
