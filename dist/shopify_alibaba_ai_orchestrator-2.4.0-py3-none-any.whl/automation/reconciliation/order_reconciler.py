from automation.reconciliation.persistent_reconciler import PersistentReconciler


class OrderReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("order", db)
