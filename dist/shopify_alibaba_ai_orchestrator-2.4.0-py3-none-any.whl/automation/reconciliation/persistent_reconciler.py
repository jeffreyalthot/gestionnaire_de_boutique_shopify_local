from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Callable, Iterable
from uuid import uuid4

from automation.reconciliation.base_reconciler import BaseReconciler, ReconciliationReport


class PersistentReconciler(BaseReconciler):
    def __init__(self, entity: str, db: Any) -> None:
        super().__init__(entity)
        self.db = db

    def run(self, local_items: Iterable[dict[str, Any]], remote_items: Iterable[dict[str, Any]], *, key: str = "id", repair: Callable[[dict[str, Any], dict[str, Any]], bool] | None = None) -> ReconciliationReport:
        identifier = str(uuid4())
        started = datetime.now(timezone.utc).isoformat()
        report = self.reconcile(local_items, remote_items, key=key, repair=repair)
        status = "completed" if not report.errors else "partial"
        finished = datetime.now(timezone.utc).isoformat()
        self.db.execute(
            "INSERT INTO reconciliation_runs(id,name,status,scanned,matched,drifted,repaired,detail_json,started_at,finished_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (identifier, self.entity, status, report.checked, report.matched, report.drifted, report.repaired, json.dumps(report.as_dict(), ensure_ascii=False), started, finished),
        )
        self.db.execute(
            "INSERT INTO reconciliation_checkpoints(name,cursor,status,detail_json,updated_at) VALUES(?,?,?,?,?) "
            "ON CONFLICT(name) DO UPDATE SET cursor=excluded.cursor,status=excluded.status,detail_json=excluded.detail_json,updated_at=excluded.updated_at",
            (self.entity, finished, status, json.dumps(report.as_dict(), ensure_ascii=False), finished),
        )
        return report
