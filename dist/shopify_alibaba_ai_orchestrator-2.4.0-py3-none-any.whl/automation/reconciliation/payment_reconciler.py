from automation.reconciliation.persistent_reconciler import PersistentReconciler


class PaymentReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("payment", db)
