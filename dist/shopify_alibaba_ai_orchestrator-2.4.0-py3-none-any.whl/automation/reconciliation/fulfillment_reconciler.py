from automation.reconciliation.persistent_reconciler import PersistentReconciler


class FulfillmentReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("fulfillment", db)
