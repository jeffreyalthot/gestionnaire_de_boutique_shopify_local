from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Iterable


@dataclass(slots=True)
class ReconciliationReport:
    entity: str
    checked: int = 0
    matched: int = 0
    drifted: int = 0
    repaired: int = 0
    errors: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class BaseReconciler:
    def __init__(self, entity: str) -> None:
        self.entity = entity

    def reconcile(self, local_items: Iterable[dict[str, Any]], remote_items: Iterable[dict[str, Any]], *, key: str = "id", repair: Callable[[dict[str, Any], dict[str, Any]], bool] | None = None) -> ReconciliationReport:
        report = ReconciliationReport(self.entity)
        remote = {str(item.get(key, "")): item for item in remote_items}
        for local in local_items:
            report.checked += 1
            identifier = str(local.get(key, ""))
            counterpart = remote.get(identifier)
            if counterpart == local:
                report.matched += 1
                continue
            report.drifted += 1
            if counterpart is not None and repair is not None:
                try:
                    if repair(local, counterpart):
                        report.repaired += 1
                except Exception as exc:
                    report.errors.append(f"{identifier}: {exc}")
        return report
