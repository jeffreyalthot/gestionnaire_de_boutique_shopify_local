from automation.reconciliation.persistent_reconciler import PersistentReconciler


class SupplierOrderReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("supplier_order", db)
