from automation.reconciliation.persistent_reconciler import PersistentReconciler


class RefundReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("refund", db)
