from automation.reconciliation.persistent_reconciler import PersistentReconciler


class CatalogReconciler(PersistentReconciler):
    def __init__(self, db):
        super().__init__("catalog", db)
