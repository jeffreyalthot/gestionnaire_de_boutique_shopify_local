def duration(seconds: float) -> str:
    seconds=int(seconds); days,seconds=divmod(seconds,86400); hours,seconds=divmod(seconds,3600); minutes,seconds=divmod(seconds,60)
    return f"{days:02d}j {hours:02d}h {minutes:02d}m {seconds:02d}s"
def money(value: float,currency: str="CAD") -> str: return f"{value:,.2f} {currency}".replace(","," ")
