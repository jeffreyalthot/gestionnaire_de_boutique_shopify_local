TITLE_STYLE="bold cyan"
OK_STYLE="green"
WARNING_STYLE="yellow"
ERROR_STYLE="bold red"
