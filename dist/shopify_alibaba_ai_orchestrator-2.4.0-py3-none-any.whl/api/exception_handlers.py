from fastapi import Request
from fastapi.responses import JSONResponse
async def unhandled_exception_handler(request: Request,exc: Exception) -> JSONResponse:
    return JSONResponse(status_code=500,content={"error":"internal_error","detail":str(exc),"path":request.url.path})
