from dataclasses import dataclass
@dataclass(slots=True)
class RequestContext:
    request_id: str
    actor: str="api"
