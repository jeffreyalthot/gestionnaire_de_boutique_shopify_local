from __future__ import annotations

import hmac

from fastapi import Header, HTTPException, Request, status


class OperatorAuthorizer:
    def __init__(self, settings) -> None:
        self.settings = settings

    async def require(self, request: Request, x_operator_token: str = Header(default="")) -> None:
        if not self.settings.api_mutations_enabled:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                                detail="Les mutations API sont désactivées.")
        if self.settings.api_loopback_only:
            host = request.client.host if request.client else ""
            if host not in {"127.0.0.1", "::1", "localhost", "testclient"}:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                                    detail="Mutation limitée à la boucle locale.")
        expected = self.settings.operator_api_token.get_secret_value()
        if not expected or not hmac.compare_digest(expected, x_operator_token):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                detail="Jeton opérateur invalide.")
