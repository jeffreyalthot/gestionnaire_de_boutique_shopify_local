from collections import defaultdict,deque
from time import monotonic
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
class RateLimiterMiddleware(BaseHTTPMiddleware):
    def __init__(self,app,limit: int=120,window: float=60) -> None:
        super().__init__(app); self.limit=limit; self.window=window; self.hits=defaultdict(deque)
    async def dispatch(self,request,call_next):
        key=request.client.host if request.client else "unknown"; now=monotonic(); q=self.hits[key]
        while q and q[0]<now-self.window: q.popleft()
        if len(q)>=self.limit: return JSONResponse({"detail":"Trop de requêtes."},status_code=429)
        q.append(now); return await call_next(request)
