from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
class BodySizeLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self,app,maximum_bytes: int=2_000_000) -> None: super().__init__(app); self.maximum=maximum_bytes
    async def dispatch(self,request,call_next):
        length=int(request.headers.get("content-length","0") or 0)
        if length>self.maximum: return JSONResponse({"detail":"Corps de requête trop volumineux."},status_code=413)
        return await call_next(request)
