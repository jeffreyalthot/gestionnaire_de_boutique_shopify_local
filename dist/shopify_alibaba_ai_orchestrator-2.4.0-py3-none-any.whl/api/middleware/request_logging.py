import time,logging
from starlette.middleware.base import BaseHTTPMiddleware
logger=logging.getLogger(__name__)
class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self,request,call_next):
        start=time.perf_counter(); response=await call_next(request)
        logger.info("%s %s -> %s %.1fms",request.method,request.url.path,response.status_code,(time.perf_counter()-start)*1000)
        return response
