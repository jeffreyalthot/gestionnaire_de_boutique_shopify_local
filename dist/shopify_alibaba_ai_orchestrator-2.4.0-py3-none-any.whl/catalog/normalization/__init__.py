"""Normalisation et publication catalogue."""
