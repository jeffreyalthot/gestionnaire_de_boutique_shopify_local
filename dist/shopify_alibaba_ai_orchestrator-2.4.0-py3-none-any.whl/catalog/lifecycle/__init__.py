"""Sous-système catalogue déterministe."""
