from ai.agents.base_agent import PolicyAwareAgent


class SupervisorAgent(PolicyAwareAgent):
    description = "Coordonne les décisions et applique les politiques d'autonomie."
    positive_signals = ('policy_score', 'consensus_score', 'audit_completeness')
    negative_signals = ('aggregate_risk', 'exception_rate')
    hard_block_signals = ('lockdown', 'policy_violation')
