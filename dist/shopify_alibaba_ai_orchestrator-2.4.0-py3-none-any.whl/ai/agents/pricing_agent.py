from ai.agents.base_agent import PolicyAwareAgent


class PricingAgent(PolicyAwareAgent):
    description = 'Valide prix, coût rendu et marge.'
    positive_signals = ('margin_score', 'price_freshness')
    negative_signals = ('cost_volatility', 'competitor_gap')
    hard_block_signals = ('negative_margin', 'stale_supplier_price')
