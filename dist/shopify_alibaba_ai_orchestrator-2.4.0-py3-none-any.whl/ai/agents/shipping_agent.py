from ai.agents.base_agent import PolicyAwareAgent


class ShippingAgent(PolicyAwareAgent):
    description = 'Sélectionne les options de livraison.'
    positive_signals = ('tracking_quality', 'carrier_score', 'delivery_confidence')
    negative_signals = ('delay_risk', 'damage_risk')
    hard_block_signals = ('undeliverable_address', 'dangerous_goods_block')
