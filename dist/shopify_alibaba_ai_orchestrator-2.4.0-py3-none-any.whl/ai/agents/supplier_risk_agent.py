from ai.agents.base_agent import PolicyAwareAgent


class SupplierRiskAgent(PolicyAwareAgent):
    description = 'Évalue le risque fournisseur.'
    positive_signals = ('verification_score', 'response_score', 'quality_score')
    negative_signals = ('dispute_rate', 'late_rate', 'price_volatility')
    hard_block_signals = ('sanctions_match', 'counterfeit_history', 'trade_assurance_missing')
