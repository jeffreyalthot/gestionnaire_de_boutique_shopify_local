from ai.agents.base_agent import PolicyAwareAgent


class AccountingAgent(PolicyAwareAgent):
    description = 'Détecte les écarts financiers.'
    positive_signals = ('reconciliation_quality', 'ledger_integrity')
    negative_signals = ('variance_ratio', 'unmatched_ratio')
    hard_block_signals = ('ledger_unbalanced', 'missing_payout')
