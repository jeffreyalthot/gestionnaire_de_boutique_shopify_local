from ai.agents.base_agent import PolicyAwareAgent


class AnomalyAgent(PolicyAwareAgent):
    description = 'Détecte les valeurs anormales.'
    positive_signals = ('data_quality', 'sample_confidence')
    negative_signals = ('anomaly_score', 'drift_score')
    hard_block_signals = ('corrupt_input',)
