from ai.agents.base_agent import PolicyAwareAgent


class ComplianceAgent(PolicyAwareAgent):
    description = 'Bloque les produits et actions non conformes.'
    positive_signals = ('compliance_score', 'evidence_score')
    negative_signals = ('restriction_risk', 'ip_risk')
    hard_block_signals = ('restricted_product', 'sanctions_match', 'counterfeit_risk')
