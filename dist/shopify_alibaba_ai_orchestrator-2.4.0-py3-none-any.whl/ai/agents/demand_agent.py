from ai.agents.base_agent import PolicyAwareAgent


class DemandAgent(PolicyAwareAgent):
    description = 'Prévoit la demande avec apprentissage incrémental.'
    positive_signals = ('forecast_confidence', 'history_quality')
    negative_signals = ('forecast_error', 'stockout_bias')
    hard_block_signals = ('insufficient_history',)
