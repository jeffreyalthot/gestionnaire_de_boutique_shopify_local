from ai.agents.base_agent import PolicyAwareAgent


class InventoryAgent(PolicyAwareAgent):
    description = 'Détecte pénuries et stock obsolète.'
    positive_signals = ('inventory_accuracy', 'supplier_availability')
    negative_signals = ('stockout_risk', 'stale_stock_ratio')
    hard_block_signals = ('negative_inventory', 'reservation_drift')
