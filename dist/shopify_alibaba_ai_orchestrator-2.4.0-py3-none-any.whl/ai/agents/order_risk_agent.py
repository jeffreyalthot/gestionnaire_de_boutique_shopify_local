from ai.agents.base_agent import PolicyAwareAgent


class OrderRiskAgent(PolicyAwareAgent):
    description = 'Classe le risque des commandes.'
    positive_signals = ('identity_confidence', 'address_quality')
    negative_signals = ('fraud_score', 'velocity_score', 'chargeback_risk')
    hard_block_signals = ('payment_mismatch', 'blocked_country', 'fraud_confirmed')
