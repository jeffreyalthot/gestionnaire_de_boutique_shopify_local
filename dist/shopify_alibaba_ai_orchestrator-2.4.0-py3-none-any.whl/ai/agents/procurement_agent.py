from ai.agents.base_agent import PolicyAwareAgent


class ProcurementAgent(PolicyAwareAgent):
    description = "Priorise les lots d'approvisionnement."
    positive_signals = ('supplier_score', 'stock_confidence', 'margin_score')
    negative_signals = ('lead_time_risk', 'cash_exposure')
    hard_block_signals = ('supplier_blocked', 'budget_exceeded')
