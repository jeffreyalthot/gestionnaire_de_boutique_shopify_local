from ai.agents.base_agent import PolicyAwareAgent


class ProductQualityAgent(PolicyAwareAgent):
    description = 'Évalue la qualité des données produit.'
    positive_signals = ('content_quality', 'media_quality', 'attribute_quality')
    negative_signals = ('return_risk', 'claim_risk')
    hard_block_signals = ('missing_required_data', 'media_rights_missing')
