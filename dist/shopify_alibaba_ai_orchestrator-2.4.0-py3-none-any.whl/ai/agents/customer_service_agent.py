from ai.agents.base_agent import PolicyAwareAgent


class CustomerServiceAgent(PolicyAwareAgent):
    description = 'Classe et prépare les réponses client.'
    positive_signals = ('intent_confidence', 'template_quality')
    negative_signals = ('sentiment_risk', 'sla_risk')
    hard_block_signals = ('legal_threat', 'payment_data_present')
