from ai.agents.base_agent import PolicyAwareAgent


class ProductScoutAgent(PolicyAwareAgent):
    description = 'Classe les produits selon potentiel, stock et marge.'
    positive_signals = ('demand_score', 'margin_score', 'supplier_score', 'quality_score')
    negative_signals = ('saturation_score', 'return_risk')
    hard_block_signals = ('restricted_product', 'supplier_blocked')
