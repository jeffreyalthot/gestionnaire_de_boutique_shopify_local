from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True, slots=True)
class ModelResult:
    value: float
    confidence: float
    reasons: tuple[str, ...] = ()
    metadata: dict[str, Any] | None = None

    def bounded(self, lower: float = 0.0, upper: float = 1.0) -> "ModelResult":
        return ModelResult(max(lower, min(upper, self.value)), max(0.0, min(1.0, self.confidence)), self.reasons, self.metadata)
