from __future__ import annotations
import math, random
from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class BanditSnapshot:
    counts: dict[str,int]
    values: dict[str,float]
    total_observations: int

class ContextualBandit:
    def __init__(self,actions: list[str],exploration: float=1.5,seed: int=42) -> None:
        if not actions or len(set(actions))!=len(actions):raise ValueError("actions uniques requises")
        self.actions=tuple(actions);self.exploration=max(0.0,float(exploration));self.counts={a:0 for a in actions};self.values={a:0.0 for a in actions};self._rng=random.Random(seed)
    def choose(self,context_scores: dict[str,float] | None=None) -> str:
        scores=context_scores or {};untried=[a for a in self.actions if self.counts[a]==0]
        if untried:return self._rng.choice(untried)
        total=max(1,sum(self.counts.values()))
        return max(self.actions,key=lambda a:self.values[a]+max(-1.0,min(1.0,float(scores.get(a,0))))+self.exploration*math.sqrt(math.log(total)/self.counts[a]))
    def update(self,action: str,reward: float) -> None:
        if action not in self.counts:raise KeyError(action)
        reward=max(-1.0,min(1.0,float(reward)));self.counts[action]+=1;n=self.counts[action];self.values[action]+=(reward-self.values[action])/n
    def snapshot(self) -> BanditSnapshot:return BanditSnapshot(dict(self.counts),dict(self.values),sum(self.counts.values()))
