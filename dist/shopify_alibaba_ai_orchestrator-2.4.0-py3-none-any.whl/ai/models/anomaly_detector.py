import numpy as np
from sklearn.linear_model import SGDOneClassSVM
class OnlineAnomalyDetector:
    def __init__(self) -> None: self.model=SGDOneClassSVM(random_state=42); self.fitted=False
    def partial_fit(self,rows: list[list[float]]) -> None:
        if rows: self.model.partial_fit(np.asarray(rows)); self.fitted=True
    def is_anomaly(self,row: list[float]) -> bool:
        return bool(self.fitted and self.model.predict(np.asarray([row]))[0]<0)
