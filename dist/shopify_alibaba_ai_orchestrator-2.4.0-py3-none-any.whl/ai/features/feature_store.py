from infrastructure.database.engine import Database
class FeatureStore:
    def __init__(self,db: Database) -> None: self.db=db
    def set(self,entity: str,entity_id: str,features: dict[str,float]) -> None: self.db.set_value(f"features:{entity}:{entity_id}",features)
    def get(self,entity: str,entity_id: str) -> dict[str,float]: return self.db.get_value(f"features:{entity}:{entity_id}",{})
