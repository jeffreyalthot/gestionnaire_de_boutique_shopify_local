import gc
def unload_reference(registry: dict[str,object],name: str) -> None:
    registry.pop(name,None); gc.collect()
