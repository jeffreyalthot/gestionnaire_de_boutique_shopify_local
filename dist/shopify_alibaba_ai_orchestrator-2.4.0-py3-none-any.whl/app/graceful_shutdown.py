import asyncio
async def cancel_tasks(tasks: list[asyncio.Task]) -> None:
    for task in tasks: task.cancel()
    await asyncio.gather(*tasks,return_exceptions=True)
