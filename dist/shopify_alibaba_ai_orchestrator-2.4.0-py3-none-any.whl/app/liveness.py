from datetime import datetime,timezone
from os import getpid
from time import monotonic
_STARTED=monotonic()
def liveness() -> dict[str,object]:return {"status":"alive","ok":True,"timestamp":datetime.now(timezone.utc).isoformat(),"pid":getpid(),"uptime_seconds":round(monotonic()-_STARTED,3)}
