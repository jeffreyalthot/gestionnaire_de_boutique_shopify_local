import asyncio,signal
def install_signal_handlers(stop_callback) -> None:
    loop=asyncio.get_running_loop()
    for sig in (signal.SIGINT,signal.SIGTERM):
        try: loop.add_signal_handler(sig,stop_callback)
        except Exception: signal.signal(sig,lambda *_: stop_callback())
