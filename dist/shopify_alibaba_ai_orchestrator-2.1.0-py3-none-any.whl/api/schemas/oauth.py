from pydantic import BaseModel
class OAuthStartResponse(BaseModel): url: str; state: str
