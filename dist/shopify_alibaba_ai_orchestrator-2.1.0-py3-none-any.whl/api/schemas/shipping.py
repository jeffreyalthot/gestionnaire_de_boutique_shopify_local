from pydantic import BaseModel
class ShippingRate(BaseModel): service_name: str; service_code: str; total_price: str; currency: str
