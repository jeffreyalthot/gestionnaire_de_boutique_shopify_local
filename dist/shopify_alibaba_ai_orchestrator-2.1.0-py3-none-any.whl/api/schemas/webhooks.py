from pydantic import BaseModel
class WebhookReceipt(BaseModel): accepted: bool; duplicate: bool=False
