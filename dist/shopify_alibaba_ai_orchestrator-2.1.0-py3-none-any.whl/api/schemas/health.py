from pydantic import BaseModel
class HealthResponse(BaseModel): status: str; database: dict[str,object]; ai: dict[str,object]
