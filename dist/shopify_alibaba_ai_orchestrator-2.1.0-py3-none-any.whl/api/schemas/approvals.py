from pydantic import BaseModel
class ApprovalDecision(BaseModel): approved: bool; actor: str; reason: str=""
