from pydantic import BaseModel
class DashboardResponse(BaseModel): counts: dict[str,int]; finance: dict[str,float]; runtime: dict[str,object]
