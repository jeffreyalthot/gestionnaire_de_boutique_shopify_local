def requires_approval(action: str,amount_cad: float,threshold: float=0) -> bool:
    return action in {"pay_supplier","refund","delete_product"} or amount_cad>threshold
