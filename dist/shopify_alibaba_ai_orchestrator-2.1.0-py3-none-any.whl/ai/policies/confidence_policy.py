def autonomous(confidence: float,minimum: float,financial: bool=False) -> bool:
    return confidence>=minimum and not financial
