def safe_action(action: str) -> bool:
    return action not in {"store_card_number","store_cvv","disable_audit","bypass_payment_confirmation"}
