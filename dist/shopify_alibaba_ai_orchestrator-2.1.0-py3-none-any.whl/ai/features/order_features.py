def order_features(o: dict[str,object]) -> dict[str,float]:
    return {"total":float(o.get("total_amount",0)),"lines":float(len(o.get("lines",[]) or [])),"customer_known":float(bool(o.get("customer_id")))}
