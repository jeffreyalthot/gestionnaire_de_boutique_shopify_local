def supplier_features(s: dict[str,object]) -> dict[str,float]:
    return {"verified":float(bool(s.get("verified"))),"years":min(1,float(s.get("years",0))/10),"response_rate":float(s.get("response_rate",0)),"dispute_rate":float(s.get("dispute_rate",0))}
