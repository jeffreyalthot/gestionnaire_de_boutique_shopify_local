def shipping_features(s: dict[str,object]) -> list[float]: return [float(s.get(k,0)) for k in ("distance","weight","supplier_delay","service_days")]
