def pricing_features(p: dict[str,object]) -> list[float]: return [float(p.get(k,0)) for k in ("supplier_cost","shipping_cost","stock","views","orders")]
