def customer_features(c: dict[str,object]) -> dict[str,float]: return {"orders":float(c.get("orders_count",0)),"spent":float(c.get("total_spent",0)),"refund_rate":float(c.get("refund_rate",0))}
