def product_features(product: dict[str,object]) -> dict[str,float]:
    return {"price":float(product.get("sale_price_cad",0)),"margin":float(product.get("margin_percent",0))/100,"stock":min(1,float(product.get("stock",0))/100),"quality":float(product.get("score",0))}
