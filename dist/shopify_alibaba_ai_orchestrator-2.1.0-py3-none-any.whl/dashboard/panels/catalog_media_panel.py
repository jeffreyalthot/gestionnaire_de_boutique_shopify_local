from dashboard.panels.base_panel import StatePanel


class CatalogMediaPanel(StatePanel):
    title = 'Catalog Media'
    fields = (('Cached', 'cached'), ('Validated', 'validated'), ('Staged', 'staged'), ('Rejected', 'rejected'))
