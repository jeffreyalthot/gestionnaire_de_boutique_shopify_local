def tax_registration_required(annual_sales_cad: float,threshold_cad: float=30000) -> bool:
    return annual_sales_cad>=threshold_cad
