def country_allowed(country_code: str,blocked: set[str]) -> bool:
    return country_code.upper() not in {x.upper() for x in blocked}
