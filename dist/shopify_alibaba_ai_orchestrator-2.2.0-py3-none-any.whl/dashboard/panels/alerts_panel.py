from rich.panel import Panel
class AlertsPanel:
    title="Alerts Panel"
    def render(self,value: object) -> Panel: return Panel(str(value),title=self.title)
