from rich.panel import Panel
class ActivityLogPanel:
    title="Activity Log Panel"
    def render(self,value: object) -> Panel: return Panel(str(value),title=self.title)
