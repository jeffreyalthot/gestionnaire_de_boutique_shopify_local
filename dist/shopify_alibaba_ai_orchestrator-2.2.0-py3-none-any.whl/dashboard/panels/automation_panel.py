from dashboard.panels.base_panel import StatePanel


class AutomationPanel(StatePanel):
    title = 'Automation'
    fields = (('Phase', 'phase'), ('Planned', 'planned'), ('Accepted', 'accepted'), ('Completed', 'completed'), ('Failed', 'failed'))
