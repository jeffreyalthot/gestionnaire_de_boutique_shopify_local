from rich.panel import Panel
class AiPanel:
    title="Ai Panel"
    def render(self,value: object) -> Panel: return Panel(str(value),title=self.title)
