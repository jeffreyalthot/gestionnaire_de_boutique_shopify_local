from rich.panel import Panel
class CashflowPanel:
    title="Cashflow Panel"
    def render(self,value: object) -> Panel: return Panel(str(value),title=self.title)
