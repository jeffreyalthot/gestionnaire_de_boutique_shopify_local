from __future__ import annotations

from typing import Any

from rich.panel import Panel
from rich.table import Table


class StatePanel:
    title = 'Panel'
    fields: tuple[tuple[str, str], ...] = ()

    def render(self, state: dict[str, Any] | Any) -> Panel:
        value = state if isinstance(state, dict) else {'value': state}
        table = Table(show_header=False, box=None, expand=True, padding=(0, 1))
        table.add_column('Metric')
        table.add_column('Value', justify='right')
        if self.fields:
            for label, key in self.fields:
                table.add_row(label, str(value.get(key, '-')))
        else:
            for key in sorted(value):
                table.add_row(str(key), str(value[key]))
        return Panel(table, title=self.title)
