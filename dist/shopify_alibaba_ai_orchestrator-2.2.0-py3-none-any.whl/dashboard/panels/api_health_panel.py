from rich.panel import Panel
class ApiHealthPanel:
    title="Api Health Panel"
    def render(self,value: object) -> Panel: return Panel(str(value),title=self.title)
