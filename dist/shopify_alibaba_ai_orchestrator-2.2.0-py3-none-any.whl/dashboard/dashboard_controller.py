class DashboardController:
    def __init__(self,container) -> None: self.container=container
    def snapshot(self) -> dict[str,object]: return self.container.dashboard_state()
