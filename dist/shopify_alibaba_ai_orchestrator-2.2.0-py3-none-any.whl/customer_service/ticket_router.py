from __future__ import annotations


class TicketRouter:
    ROUTES = {"chargeback": "finance", "fraud": "risk", "lost_package": "fulfillment", "damaged_item": "returns", "refund": "returns", "cancellation": "orders", "shipping": "fulfillment"}

    def route(self, category: str) -> str:
        return self.ROUTES.get(category, "customer_service")
