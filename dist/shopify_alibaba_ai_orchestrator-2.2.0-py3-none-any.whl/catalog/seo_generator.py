import re
def seo_fields(title: str,description: str) -> dict[str,str]:
    text=re.sub("<[^>]+>"," ",description); text=re.sub(r"\s+"," ",text).strip()
    return {"title":title[:70],"description":text[:160]}
