from integrations.alibaba.mappers.product_mapper import map_alibaba_product
class ProductNormalizer:
    def normalize(self,payload: dict[str,object]) -> dict[str,object]: return map_alibaba_product(payload)
