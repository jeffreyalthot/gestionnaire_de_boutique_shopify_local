class CategoryMapper:
    def __init__(self,mapping: dict[str,str]|None=None) -> None: self.mapping=mapping or {}
    def shopify_type(self,alibaba_category_id: str,fallback: str="General") -> str:
        return self.mapping.get(alibaba_category_id,fallback)
