from difflib import SequenceMatcher
class DuplicateDetector:
    def similar(self,a: str,b: str,threshold: float=0.92) -> bool:
        return SequenceMatcher(None,a.lower().strip(),b.lower().strip()).ratio()>=threshold
