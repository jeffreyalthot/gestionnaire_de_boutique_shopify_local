def quality_score(product: dict[str,object]) -> float:
    score=0.0
    if product.get("title"): score+=0.2
    if len(product.get("images",[]) or [])>=3: score+=0.2
    if product.get("skus"): score+=0.2
    if float(product.get("price",0) or 0)>0: score+=0.2
    if product.get("supplier"): score+=0.2
    return round(score,4)
