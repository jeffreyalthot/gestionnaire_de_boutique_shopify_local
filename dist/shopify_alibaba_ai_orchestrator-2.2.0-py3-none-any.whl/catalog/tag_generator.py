import re
def generate_tags(title: str,category: str,supplier: str="") -> list[str]:
    words=[w.lower() for w in re.findall(r"[A-Za-zÀ-ÿ0-9]{4,}",title)]
    values=["alibaba-import",category.strip().lower(),supplier.strip().lower(),*words[:8]]
    return list(dict.fromkeys(v for v in values if v))[:20]
