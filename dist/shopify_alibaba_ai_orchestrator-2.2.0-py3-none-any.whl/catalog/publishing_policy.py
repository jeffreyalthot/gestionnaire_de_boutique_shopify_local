def should_publish(score: float,eligible: bool,stock: int,minimum_score: float=0.70) -> bool:
    return eligible and score>=minimum_score and stock>0
