from catalog.image_validator import valid_image_urls
def shopify_files(urls: list[str],title: str) -> list[dict[str,str]]:
    return [{"originalSource":url,"alt":f"{title} — image {i+1}","contentType":"IMAGE"} for i,url in enumerate(valid_image_urls(urls))]
