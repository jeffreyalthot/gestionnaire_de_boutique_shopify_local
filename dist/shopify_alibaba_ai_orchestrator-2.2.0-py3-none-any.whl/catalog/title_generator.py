import re
def generate_title(raw_title: str,maximum: int=120) -> str:
    clean=re.sub(r"\s+"," ",raw_title).strip()
    return clean[:maximum].rstrip(" ,;:-")
