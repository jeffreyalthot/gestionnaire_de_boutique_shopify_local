from app.exception_router import ExceptionRouter, RoutedException


class ExceptionClassifier(ExceptionRouter):
    pass


__all__ = ["ExceptionClassifier", "RoutedException"]
