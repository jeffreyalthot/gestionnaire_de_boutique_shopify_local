from __future__ import annotations

import os
from dataclasses import asdict, dataclass
from threading import RLock
from typing import Any

import psutil


@dataclass(frozen=True, slots=True)
class RuntimeBudget:
    max_rss_mb: float = 850.0
    max_cpu_percent: float = 75.0
    max_http_concurrency: int = 2
    max_heavy_operations_per_cycle: int = 1
    max_pending_tasks: int = 5000
    max_media_cache_mb: int = 256
    worker_threads: int = 2


class ResourceGovernor:
    def __init__(self, budget: RuntimeBudget) -> None:
        self.budget = budget
        self._process = psutil.Process(os.getpid())
        self._lock = RLock()
        self._heavy_used = 0
        self._cycle_id = ""

    def begin_cycle(self, cycle_id: str) -> None:
        with self._lock:
            self._cycle_id = cycle_id
            self._heavy_used = 0

    def sample(self) -> dict[str, Any]:
        rss_mb = self._process.memory_info().rss / 1048576
        cpu = self._process.cpu_percent(None)
        return {
            "rss_mb": round(rss_mb, 2),
            "cpu_percent": round(cpu, 2),
            "within_memory_budget": rss_mb <= self.budget.max_rss_mb,
            "within_cpu_budget": cpu <= self.budget.max_cpu_percent,
            "cycle_id": self._cycle_id,
            "heavy_used": self._heavy_used,
            "budget": asdict(self.budget),
        }

    def allow(self, *, heavy: bool = False, pending_tasks: int = 0) -> tuple[bool, str]:
        with self._lock:
            sample = self.sample()
            if not sample["within_memory_budget"]:
                return False, "memory_budget_exceeded"
            if pending_tasks >= self.budget.max_pending_tasks:
                return False, "queue_backpressure"
            if heavy and self._heavy_used >= self.budget.max_heavy_operations_per_cycle:
                return False, "heavy_operation_budget_exhausted"
            if heavy:
                self._heavy_used += 1
            return True, "allowed"
