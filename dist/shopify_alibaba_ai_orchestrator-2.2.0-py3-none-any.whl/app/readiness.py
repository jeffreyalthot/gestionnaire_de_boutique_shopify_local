def readiness(container) -> dict[str,object]:
    db=container.db.health()
    return {"ready":bool(db["ok"]),"database":db,"dry_run":container.settings.app_dry_run}
