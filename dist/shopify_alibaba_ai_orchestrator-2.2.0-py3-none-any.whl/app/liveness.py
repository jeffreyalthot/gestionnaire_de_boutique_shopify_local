from datetime import datetime,timezone
def liveness() -> dict[str,str]: return {"status":"alive","timestamp":datetime.now(timezone.utc).isoformat()}
