from customers.customer_consent import CustomerConsent


class ConsentLedger(CustomerConsent):
    pass
