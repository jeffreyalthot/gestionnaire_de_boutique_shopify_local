from infrastructure.database.engine import Database
class LongTermMemory:
    def __init__(self,db: Database) -> None: self.db=db
    def remember(self,key: str,value: object) -> None: self.db.set_value(f"ai-memory:{key}",value)
    def recall(self,key: str,default=None): return self.db.get_value(f"ai-memory:{key}",default)
