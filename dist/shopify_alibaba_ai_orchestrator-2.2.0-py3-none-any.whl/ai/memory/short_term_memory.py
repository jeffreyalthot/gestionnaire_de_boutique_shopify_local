from collections import deque
class ShortTermMemory:
    def __init__(self,maximum: int=500) -> None: self.items=deque(maxlen=maximum)
    def add(self,item: dict[str,object]) -> None: self.items.append(item)
    def recent(self,count: int=20) -> list[dict[str,object]]: return list(self.items)[-count:]
