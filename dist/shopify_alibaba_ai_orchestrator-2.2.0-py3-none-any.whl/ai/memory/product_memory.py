from ai.memory.long_term_memory import LongTermMemory
class ProductMemory(LongTermMemory):
    prefix="product"
    def put(self,key: str,value: object) -> None: self.remember(f"{self.prefix}:{key}",value)
    def get(self,key: str,default=None): return self.recall(f"{self.prefix}:{key}",default)
