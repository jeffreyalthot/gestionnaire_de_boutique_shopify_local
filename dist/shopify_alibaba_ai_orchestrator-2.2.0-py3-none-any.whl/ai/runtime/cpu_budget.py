import os,psutil
class CPUBudget:
    def __init__(self,maximum_percent: float) -> None: self.maximum=maximum_percent; self.process=psutil.Process(os.getpid())
    def current(self) -> float: return self.process.cpu_percent(interval=None)
    def overloaded(self) -> bool: return self.current()>self.maximum
