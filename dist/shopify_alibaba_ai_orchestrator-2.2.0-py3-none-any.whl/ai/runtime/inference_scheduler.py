import asyncio
class InferenceScheduler:
    def __init__(self,workers: int=1) -> None: self.semaphore=asyncio.Semaphore(workers)
    async def run(self,callable_,*args,**kwargs):
        async with self.semaphore:
            return await asyncio.to_thread(callable_,*args,**kwargs)
