class ModelRegistry:
    def __init__(self) -> None: self._models: dict[str,object]={}
    def register(self,name: str,model: object) -> None: self._models[name]=model
    def get(self,name: str): return self._models[name]
    def unload(self,name: str) -> None: self._models.pop(name,None)
    def names(self) -> list[str]: return sorted(self._models)
