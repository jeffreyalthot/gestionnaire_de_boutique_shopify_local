class FallbackEngine:
    def classify(self,text: str) -> str:
        lower=text.lower()
        if any(x in lower for x in ("refund","rembourse")): return "refund"
        if any(x in lower for x in ("tracking","suivi","livraison")): return "shipping"
        if any(x in lower for x in ("cancel","annul")): return "cancellation"
        return "general"
