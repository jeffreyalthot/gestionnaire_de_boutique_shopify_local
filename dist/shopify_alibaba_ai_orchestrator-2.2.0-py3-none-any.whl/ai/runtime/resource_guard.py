from contextlib import contextmanager
from typing import Iterator
from ai.runtime.memory_budget import MemoryBudget
from ai.runtime.cpu_budget import CPUBudget
class ResourceGuard:
    def __init__(self,memory: MemoryBudget,cpu: CPUBudget) -> None: self.memory=memory; self.cpu=cpu
    @contextmanager
    def inference(self,reserve_mb: float=10) -> Iterator[None]:
        self.memory.require(reserve_mb)
        if self.cpu.overloaded(): raise RuntimeError("CPU au-dessus du budget IA.")
        yield
