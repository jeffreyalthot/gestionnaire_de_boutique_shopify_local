from __future__ import annotations
from uuid import uuid4
import json
from config.settings import Settings
from infrastructure.database.engine import Database,utcnow
from ai.runtime.memory_budget import MemoryBudget
from ai.runtime.cpu_budget import CPUBudget
from ai.runtime.resource_guard import ResourceGuard
from ai.runtime.inference_scheduler import InferenceScheduler
from ai.runtime.model_registry import ModelRegistry
from ai.models.text_category_model import TextCategoryModel
from ai.models.product_ranker import product_rank
from ai.models.supplier_risk_model import supplier_risk

class AIRuntime:
    def __init__(self,settings: Settings,db: Database) -> None:
        self.settings=settings; self.db=db
        self.memory=MemoryBudget(settings.ai_max_ram_mb); self.cpu=CPUBudget(settings.ai_max_cpu_percent)
        self.guard=ResourceGuard(self.memory,self.cpu); self.scheduler=InferenceScheduler(settings.ai_worker_threads)
        self.registry=ModelRegistry(); self.category_model=TextCategoryModel(); self.registry.register("category",self.category_model)

    def status(self) -> dict[str,object]:
        snap=self.memory.snapshot()
        return {"enabled":self.settings.ai_enabled,"profile":self.settings.ai_profile,
                "rss_mb":snap.rss_mb,"limit_mb":snap.limit_mb,"within_budget":snap.within_budget,
                "models":self.registry.names()}

    async def score_product(self,features: dict[str,float],entity_id: str="") -> dict[str,object]:
        if not self.settings.ai_enabled: return {"score":0.5,"confidence":0.0}
        with self.guard.inference():
            score=await self.scheduler.run(product_rank,features)
        confidence=min(0.99,0.70+abs(score-0.5)*0.5)
        self._record("product_selection",entity_id,confidence,"accept" if score>=0.7 else "review",features)
        return {"score":score,"confidence":confidence}

    async def score_supplier(self,features: dict[str,float],entity_id: str="") -> dict[str,object]:
        with self.guard.inference():
            risk=await self.scheduler.run(supplier_risk,features.get("dispute_rate",0),features.get("response_rate",0),
                                          features.get("years",0),bool(features.get("verified",0)))
        confidence=0.85
        self._record("supplier_risk",entity_id,confidence,"approve" if risk<0.3 else "review",features)
        return {"risk":risk,"confidence":confidence}

    def _record(self,decision_type: str,entity_id: str,confidence: float,action: str,features: dict[str,float]) -> str:
        decision_id=str(uuid4())
        self.db.execute("INSERT INTO ai_decisions(id,decision_type,entity_id,confidence,action,features_json,created_at) VALUES(?,?,?,?,?,?,?)",
                        (decision_id,decision_type,entity_id,confidence,action,json.dumps(features),utcnow()))
        return decision_id
