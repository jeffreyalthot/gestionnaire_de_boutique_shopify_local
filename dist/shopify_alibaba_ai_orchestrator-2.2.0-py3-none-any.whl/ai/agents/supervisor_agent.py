class SupervisorAgent:
    description="Coordonne les décisions et applique les politiques d'autonomie."
    def decide(self,context: dict[str,object]) -> dict[str,object]:
        confidence=float(context.get("confidence",0.75))
        return {"agent":self.__class__.__name__,"confidence":confidence,"decision":"review" if confidence<0.92 else "approve"}
