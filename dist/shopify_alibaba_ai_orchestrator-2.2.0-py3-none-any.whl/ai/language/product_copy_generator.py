from catalog.title_generator import generate_title
from catalog.description_generator import generate_description
class ProductCopyGenerator:
    def generate(self,title: str,attributes: dict[str,object],description: str="") -> dict[str,str]:
        clean=generate_title(title); return {"title":clean,"description_html":generate_description(clean,attributes,description)}
