from string import Template
class TemplateEngine:
    def render(self,template: str,values: dict[str,object]) -> str: return Template(template).safe_substitute({k:str(v) for k,v in values.items()})
