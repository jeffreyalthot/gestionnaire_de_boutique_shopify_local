import re
def sanitize(text: str,maximum: int=5000) -> str:
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]","",text).strip()[:maximum]
