class CustomerReplyGenerator:
    def tracking(self,name: str,tracking_number: str,url: str) -> str:
        return f"Bonjour {name}, votre commande est expédiée. Numéro de suivi : {tracking_number}. Suivi : {url}"
    def delay(self,name: str,new_date: str) -> str:
        return f"Bonjour {name}, nous vous informons que la livraison est maintenant prévue pour le {new_date}. Nous suivons activement l'expédition."
