class TranslationAdapter:
    def translate(self,text: str,source: str,target: str) -> str:
        if source==target: return text
        raise RuntimeError("Aucun modèle de traduction local n'est chargé pour cette paire linguistique.")
