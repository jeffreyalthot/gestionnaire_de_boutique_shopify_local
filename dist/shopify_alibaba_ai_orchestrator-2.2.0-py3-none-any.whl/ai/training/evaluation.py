def binary_metrics(labels: list[int],predictions: list[int]) -> dict[str,float]:
    if not labels: return {"accuracy":0.0,"precision":0.0,"recall":0.0}
    tp=sum(a==b==1 for a,b in zip(labels,predictions)); tn=sum(a==b==0 for a,b in zip(labels,predictions))
    fp=sum(a==0 and b==1 for a,b in zip(labels,predictions)); fn=sum(a==1 and b==0 for a,b in zip(labels,predictions))
    return {"accuracy":(tp+tn)/len(labels),"precision":tp/max(1,tp+fp),"recall":tp/max(1,tp+fn)}
