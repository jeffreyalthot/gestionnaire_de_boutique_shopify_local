from pathlib import Path
import shutil
def rollback_model(rollback_path: Path,active_path: Path) -> None:
    if not rollback_path.is_file(): raise FileNotFoundError(rollback_path)
    active_path.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(rollback_path,active_path)
