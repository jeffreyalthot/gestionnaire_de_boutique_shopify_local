from collections import deque
class DriftDetector:
    def __init__(self,window: int=100,threshold: float=0.15) -> None: self.values=deque(maxlen=window); self.threshold=threshold
    def update(self,error: float) -> bool:
        self.values.append(error)
        if len(self.values)<self.values.maxlen: return False
        half=len(self.values)//2; a=sum(list(self.values)[:half])/half; b=sum(list(self.values)[half:])/(len(self.values)-half)
        return b-a>self.threshold
