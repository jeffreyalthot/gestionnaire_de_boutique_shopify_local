from infrastructure.database.engine import Database
class FeedbackCollector:
    def __init__(self,db: Database) -> None: self.db=db
    def record(self,decision_id: str,outcome: float) -> None: self.db.execute("UPDATE ai_decisions SET outcome=? WHERE id=?",(outcome,decision_id))
