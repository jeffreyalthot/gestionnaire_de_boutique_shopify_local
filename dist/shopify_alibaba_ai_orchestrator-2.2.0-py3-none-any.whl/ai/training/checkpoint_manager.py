from pathlib import Path
import joblib
class CheckpointManager:
    def save(self,model: object,path: Path) -> Path: path.parent.mkdir(parents=True,exist_ok=True); joblib.dump(model,path,compress=3); return path
    def load(self,path: Path): return joblib.load(path)
