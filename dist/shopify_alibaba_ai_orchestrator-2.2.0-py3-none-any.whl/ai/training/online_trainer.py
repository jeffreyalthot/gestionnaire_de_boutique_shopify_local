class OnlineTrainer:
    def __init__(self,models: dict[str,object]) -> None: self.models=models
    def train_text(self,name: str,texts: list[str],labels: list[str]) -> None:
        model=self.models[name]; model.partial_fit(texts,labels)
