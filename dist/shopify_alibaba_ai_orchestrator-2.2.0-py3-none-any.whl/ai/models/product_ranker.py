def product_rank(features: dict[str,float]) -> float:
    weights={"quality":0.25,"supplier":0.20,"margin":0.20,"stock":0.15,"delivery":0.10,"demand":0.10}
    return max(0.0,min(1.0,sum(features.get(k,0)*w for k,w in weights.items())))
