from ai.models.online_regressor import OnlineRegressor
class ReturnProbabilityModel(OnlineRegressor):
    def probability(self,features: list[float]) -> float: return max(0.0,min(1.0,self.predict(features,0.05)))
