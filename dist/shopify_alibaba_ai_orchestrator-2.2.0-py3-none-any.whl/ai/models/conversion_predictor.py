from ai.models.online_classifier import OnlineTextClassifier
class ConversionPredictor(OnlineTextClassifier):
    def __init__(self) -> None: super().__init__(["low","high"])
