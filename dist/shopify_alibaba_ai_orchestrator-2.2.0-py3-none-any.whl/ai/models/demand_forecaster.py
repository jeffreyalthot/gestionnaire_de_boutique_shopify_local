from ai.models.online_regressor import OnlineRegressor
class DemandForecaster(OnlineRegressor):
    def features(self,views: float,orders: float,stock: float,price: float) -> list[float]: return [views,orders,stock,price]
