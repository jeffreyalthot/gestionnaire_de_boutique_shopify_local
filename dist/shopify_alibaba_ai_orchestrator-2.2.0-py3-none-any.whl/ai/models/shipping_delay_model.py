from ai.models.online_regressor import OnlineRegressor
class ShippingDelayModel(OnlineRegressor):
    def expected_days(self,features: list[float]) -> float: return max(0.0,self.predict(features,14))
