from ai.models.online_classifier import OnlineTextClassifier
class TextCategoryModel(OnlineTextClassifier):
    def __init__(self) -> None: super().__init__(["general","electronics","home","fashion","beauty","sports","automotive"])
