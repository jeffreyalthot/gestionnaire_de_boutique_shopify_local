from __future__ import annotations
import math,random
class ContextualBandit:
    def __init__(self,actions: list[str],exploration: float=1.5) -> None:
        self.actions=actions; self.exploration=exploration; self.counts={a:0 for a in actions}; self.values={a:0.0 for a in actions}
    def choose(self) -> str:
        untried=[a for a in self.actions if self.counts[a]==0]
        if untried: return random.choice(untried)
        total=sum(self.counts.values())
        return max(self.actions,key=lambda a:self.values[a]+self.exploration*math.sqrt(math.log(total)/self.counts[a]))
    def update(self,action: str,reward: float) -> None:
        self.counts[action]+=1; n=self.counts[action]; self.values[action]+=(reward-self.values[action])/n
