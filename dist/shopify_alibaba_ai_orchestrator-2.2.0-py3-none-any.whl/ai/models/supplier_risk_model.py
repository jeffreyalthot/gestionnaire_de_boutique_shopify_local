def supplier_risk(dispute_rate: float,response_rate: float,years: float,verified: bool) -> float:
    risk=0.4*min(1,dispute_rate*5)+0.3*(1-min(1,response_rate))+0.2*(1-min(1,years/10))+0.1*(not verified)
    return max(0.0,min(1.0,float(risk)))
