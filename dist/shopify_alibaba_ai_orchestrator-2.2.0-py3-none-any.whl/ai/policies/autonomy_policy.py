from ai.policies.confidence_policy import autonomous
from ai.policies.safe_action_policy import safe_action
def may_execute(action: str,confidence: float,minimum: float,financial: bool=False) -> bool:
    return safe_action(action) and autonomous(confidence,minimum,financial)
