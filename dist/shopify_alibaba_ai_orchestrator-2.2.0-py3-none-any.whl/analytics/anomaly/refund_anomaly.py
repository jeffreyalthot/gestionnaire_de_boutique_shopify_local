from analytics.anomaly.base import RobustAnomalyDetector


class RefundAnomaly(RobustAnomalyDetector):
    metric = "refunds"
