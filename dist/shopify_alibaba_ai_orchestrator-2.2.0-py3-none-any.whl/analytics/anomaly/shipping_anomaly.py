from analytics.anomaly.base import RobustAnomalyDetector


class ShippingAnomaly(RobustAnomalyDetector):
    metric = "shipping"
