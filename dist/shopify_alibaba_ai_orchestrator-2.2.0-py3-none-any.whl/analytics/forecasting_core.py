from __future__ import annotations

from analytics.forecasting import moving_average_forecast


class MovingAverageForecaster:
    metric = "value"

    def forecast(self, values: list[float], *, periods: int = 7, horizon: int = 7) -> dict[str, object]:
        return {"metric": self.metric, "horizon": horizon, "values": moving_average_forecast(values, periods, horizon)}
