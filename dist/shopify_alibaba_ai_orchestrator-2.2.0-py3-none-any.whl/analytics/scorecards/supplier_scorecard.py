from analytics.scorecards.base import ScorecardBuilder


class SupplierScorecard(ScorecardBuilder):
    name = "supplier"
    weights = {'quality': 0.3, 'delivery': 0.25, 'response': 0.15, 'price': 0.15, 'disputes': 0.15}
