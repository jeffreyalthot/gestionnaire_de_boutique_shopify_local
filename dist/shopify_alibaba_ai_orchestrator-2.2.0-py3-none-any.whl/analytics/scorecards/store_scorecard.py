from analytics.scorecards.base import ScorecardBuilder


class StoreScorecard(ScorecardBuilder):
    name = "store"
    weights = {'profitability': 0.3, 'fulfillment': 0.2, 'customer': 0.2, 'compliance': 0.15, 'reliability': 0.15}
