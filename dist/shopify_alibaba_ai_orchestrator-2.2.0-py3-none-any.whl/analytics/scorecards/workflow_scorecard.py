from analytics.scorecards.base import ScorecardBuilder


class WorkflowScorecard(ScorecardBuilder):
    name = "workflow"
    weights = {'success': 0.35, 'latency': 0.2, 'retries': 0.15, 'idempotency': 0.15, 'reconciliation': 0.15}
