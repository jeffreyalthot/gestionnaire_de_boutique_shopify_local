from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class Scorecard:
    name: str
    score: float
    grade: str
    metrics: dict[str, float]
    issues: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class ScorecardBuilder:
    name = "generic"
    weights: dict[str, float] = {}

    def build(self, metrics: dict[str, float], issues: tuple[str, ...] = ()) -> Scorecard:
        if self.weights:
            denom = sum(abs(v) for v in self.weights.values()) or 1.0
            score = sum(max(0.0, min(1.0, float(metrics.get(k, 0.0)))) * w for k, w in self.weights.items()) / denom
        else:
            score = sum(max(0.0, min(1.0, float(v))) for v in metrics.values()) / max(1, len(metrics))
        score = max(0.0, min(1.0, score - min(0.30, 0.03 * len(issues))))
        grade = "A" if score >= 0.90 else ("B" if score >= 0.80 else ("C" if score >= 0.70 else ("D" if score >= 0.60 else "F")))
        return Scorecard(self.name, round(score, 6), grade, dict(metrics), tuple(issues))
