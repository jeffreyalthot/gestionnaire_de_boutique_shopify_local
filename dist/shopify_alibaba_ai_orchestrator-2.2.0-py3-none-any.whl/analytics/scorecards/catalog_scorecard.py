from analytics.scorecards.base import ScorecardBuilder


class CatalogScorecard(ScorecardBuilder):
    name = "catalog"
    weights = {'quality': 0.3, 'margin': 0.25, 'stock': 0.2, 'media': 0.15, 'compliance': 0.1}
