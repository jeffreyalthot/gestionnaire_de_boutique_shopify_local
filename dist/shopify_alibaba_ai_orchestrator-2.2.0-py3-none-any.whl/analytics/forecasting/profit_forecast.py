from analytics.forecasting_core import MovingAverageForecaster


class ProfitForecast(MovingAverageForecaster):
    metric = "profit"
