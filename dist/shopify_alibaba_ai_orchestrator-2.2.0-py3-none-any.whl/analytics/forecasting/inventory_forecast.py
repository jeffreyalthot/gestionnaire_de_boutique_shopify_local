from analytics.forecasting_core import MovingAverageForecaster


class InventoryForecast(MovingAverageForecaster):
    metric = "inventory"
