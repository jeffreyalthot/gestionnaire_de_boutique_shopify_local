from analytics.forecasting_core import MovingAverageForecaster


class RevenueForecast(MovingAverageForecaster):
    metric = "revenue"
