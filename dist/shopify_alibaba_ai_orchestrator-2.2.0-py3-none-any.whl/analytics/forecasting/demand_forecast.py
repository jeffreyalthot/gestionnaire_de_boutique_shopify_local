from analytics.forecasting_core import MovingAverageForecaster


class DemandForecast(MovingAverageForecaster):
    metric = "demand"
