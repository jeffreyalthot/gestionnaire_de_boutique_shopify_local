from analytics.forecasting_core import MovingAverageForecaster


class ShippingForecast(MovingAverageForecaster):
    metric = "shipping_days"
