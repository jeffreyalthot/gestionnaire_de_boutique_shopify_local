def get_container(request):
    return request.app.state.container
