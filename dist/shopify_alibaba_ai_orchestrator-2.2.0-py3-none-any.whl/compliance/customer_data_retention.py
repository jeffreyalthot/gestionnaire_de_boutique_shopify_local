from security.data_retention import retention_cutoff
from infrastructure.database.engine import Database
def purge_expired_addresses(db: Database,days: int) -> int:
    return db.execute("UPDATE orders SET encrypted_shipping_address='' WHERE updated_at<?",(retention_cutoff(days),))
