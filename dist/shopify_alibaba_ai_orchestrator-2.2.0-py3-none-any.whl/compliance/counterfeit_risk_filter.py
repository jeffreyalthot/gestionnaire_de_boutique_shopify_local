import re
def counterfeit_risk(text: str) -> float:
    hits=sum(bool(re.search(p,text,re.I)) for p in (r"\breplica\b",r"\bcopy\b",r"\b1:1\b",r"\binspired by\b"))
    return min(1.0,hits/2)
