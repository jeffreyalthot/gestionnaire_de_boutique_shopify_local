from __future__ import annotations

from typing import Any, Iterable

from compliance.base import ComplianceFinding, ComplianceResult


class ComplianceOrchestrator:
    def evaluate(self, checks: Iterable[tuple[str, Any]]) -> ComplianceResult:
        findings: list[ComplianceFinding] = []
        for name, result in checks:
            for finding in getattr(result, "findings", ()):
                findings.append(ComplianceFinding(
                    code=f"{name}.{finding.code}", severity=finding.severity, message=finding.message,
                    blocking=finding.blocking, evidence=finding.evidence,
                ))
        return ComplianceResult(not any(item.blocking for item in findings), tuple(findings), bool(findings))
