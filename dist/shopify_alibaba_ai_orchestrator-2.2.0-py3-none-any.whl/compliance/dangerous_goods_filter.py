import re
def dangerous_goods_reason(text: str) -> str:
    patterns={"battery":r"lithium battery","chemical":r"flammable|corrosive|toxic","compressed gas":r"aerosol|compressed gas"}
    return next((k for k,p in patterns.items() if re.search(p,text,re.I)),"")
