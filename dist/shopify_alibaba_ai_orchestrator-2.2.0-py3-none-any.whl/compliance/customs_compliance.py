def customs_fields(sku: str,hs_code: str,country_of_origin: str,unit_cost: float) -> dict[str,object]:
    if not sku or not hs_code or len(country_of_origin)!=2 or unit_cost<0: raise ValueError("Données douanières invalides.")
    return {"sku":sku,"harmonizedSystemCode":hs_code,"countryCodeOfOrigin":country_of_origin.upper(),"cost":unit_cost}
