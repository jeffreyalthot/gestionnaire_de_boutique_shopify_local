def compliance_summary(checks: dict[str,bool]) -> dict[str,object]:
    failed=sorted(k for k,v in checks.items() if not v)
    return {"ok":not failed,"passed":sum(checks.values()),"total":len(checks),"failed":failed}
