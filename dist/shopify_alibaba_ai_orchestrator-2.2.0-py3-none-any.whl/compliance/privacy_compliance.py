PII_FIELDS={"email","phone","address1","address2","zip","postal_code","first_name","last_name"}
def minimize_payload(payload: dict[str,object],allow_pii: bool=False) -> dict[str,object]:
    return {k:v for k,v in payload.items() if allow_pii or k.lower() not in PII_FIELDS}
