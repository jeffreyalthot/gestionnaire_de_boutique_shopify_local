from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class ComplianceFinding:
    code: str
    severity: str
    message: str
    blocking: bool = False
    evidence: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ComplianceResult:
    passed: bool
    findings: tuple[ComplianceFinding, ...]
    review_required: bool

    def as_dict(self) -> dict[str, Any]:
        return {"passed": self.passed, "review_required": self.review_required,
                "findings": tuple(item.as_dict() for item in self.findings)}


def result(*findings: ComplianceFinding) -> ComplianceResult:
    return ComplianceResult(not any(item.blocking for item in findings), tuple(findings), bool(findings))
