def contains_protected_brand(title: str,brands: set[str]) -> str:
    lower=title.lower()
    return next((brand for brand in brands if brand.lower() in lower),"")
