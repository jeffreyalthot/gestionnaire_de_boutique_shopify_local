class CommandRouter:
    def __init__(self) -> None: self.handlers={}
    def register(self,name: str,handler) -> None: self.handlers[name]=handler
    async def execute(self,name: str,*args):
        if name not in self.handlers: raise KeyError(name)
        result=self.handlers[name](*args); return await result if hasattr(result,"__await__") else result
