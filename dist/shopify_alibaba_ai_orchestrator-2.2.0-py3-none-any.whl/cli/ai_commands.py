class AiCommands:
    resource="ai"
    def __init__(self,container) -> None: self.container=container
    def execute(self) -> dict[str,object]: return self.container.status()
